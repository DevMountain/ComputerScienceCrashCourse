import Foundation

//(This Queue is used in the implementation of a Tree)
//public struct Queue<T> {
//    
//    fileprivate var array = [T]()
//    
//    public var isEmpty: Bool {
//        return array.isEmpty
//    }
//    
//    public mutating func enqueue(_ element: T) {
//        array.append(element)
//    }
//    
//    public mutating func dequeue() -> T? {
//        if isEmpty {
//            return nil
//        } else {
//            return array.removeFirst()
//        }
//    }
//    
//    public mutating func peek() -> T? {
//        return array.first
//    }
//}
