// Week 3 - Day 3 - Set, Set Theory


// What is a Set?
// An unorganized group of elements.
// There are NO DUPLICATES!!!

// When would be use a set?

// Two variations on Sets.

// TreeSet vs. HashSet

// Advantages and Disadvantages
















// Set Theroy

// 1. Definitions and Notation
// Set
// Ordered Pairs
// Element
// Subset and Not Subset
// Proper Subset and Not Proper Subset
// Compliment
// Cardinality
// Empty Set
// Power Set






















// 2. Operations
// Union
// Intersection
// Difference
// Cartesian Product






























// 3. Infinite Sets
// Universal Set = U
// Natural Numbers
// Integers
// Real Numbers
